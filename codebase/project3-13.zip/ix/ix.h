#ifndef _ix_h_
#define _ix_h_

#include <vector>
#include <string>

#include "../rbf/rbfm.h"
#include "../rbf/pfm.h"


# define IX_EOF (-1)  // end of the index scan

#define SUCCESS 0
#define ERROR 1
#define DOESNT_FIT 2

class IX_ScanIterator;
class IXFileHandle;

typedef struct indexDirectoryHeader
{
    bool isLeaf;
    uint16_t freeSpaceOffset;
    uint16_t nodeCount;
} indexDirectoryHeader;




class IndexManager {

    public:
        static IndexManager* instance();

        // Create an index file.
        RC createFile(const string &fileName);

        // Delete an index file.
        RC destroyFile(const string &fileName);

        // Open an index and return an ixfileHandle.
        RC openFile(const string &fileName, IXFileHandle &ixfileHandle);

        // Close an ixfileHandle for an index.
        RC closeFile(IXFileHandle &ixfileHandle);

        // Insert an entry into the given index that is indicated by the given ixfileHandle.
        RC insertEntry(IXFileHandle &ixfileHandle, const Attribute &attribute, const void *key, const RID &rid);

        // Delete an entry from the given index that is indicated by the given ixfileHandle.
        RC deleteEntry(IXFileHandle &ixfileHandle, const Attribute &attribute, const void *key, const RID &rid);

        // Initialize and IX_ScanIterator to support a range search
        RC scan(IXFileHandle &ixfileHandle,
                const Attribute &attribute,
                const void *lowKey,
                const void *highKey,
                bool lowKeyInclusive,
                bool highKeyInclusive,
                IX_ScanIterator &ix_ScanIterator);

        // Print the B+ tree in pre-order (in a JSON record format)
        void printBtree(IXFileHandle &ixfileHandle, const Attribute &attribute) const;
    protected:
        IndexManager();
        ~IndexManager();

    private:
        static IndexManager *_index_manager;
	static PagedFileManager *_pf_manager;
	void newNonLeafPage(void * page, unsigned pageNum, unsigned pageZeroNum);
	void setIndexDirectoryHeader(void * page, indexDirectoryHeader indexHeader);
        bool fileExists(const string &fileName);
	void setPageNumAtOffset(void * page, int32_t offset, uint32_t pageNum);
	void newLeafPage(void * page, unsigned pageNum);
	RC insertEntryRec(unsigned pageNum, IXFileHandle &ixfileHandle, const Attribute &attribute, const void *key, const RID &rid, void * copyKey);
	indexDirectoryHeader getIndexDirectoryHeader(void * page);
	unsigned getChildPage(void * page, const void *key, indexDirectoryHeader header, const Attribute &attribute);
	RC prepPage(void * page, const void *key, indexDirectoryHeader header,  const Attribute &attribute, const RID &rid, unsigned pageNum);
	unsigned getTotalFreeSpace(void * page, indexDirectoryHeader header);
	unsigned getKeySize(const void *key, const Attribute &attribute);
	void insertOffset(void * page, const void *key, indexDirectoryHeader header, unsigned offset, const Attribute &attribute);
	unsigned findInsertionSlot(void * page, const void *key, indexDirectoryHeader header, const Attribute &attribute);
	void getKeyAtOffset(void * page, void *key, unsigned offset, const Attribute &attribute);
	bool greaterEqual(const void * key1, void * key2, const Attribute &attribute);
	void getKeyAtSlot(void * page, void *key, unsigned slot, const Attribute &attribute);
	unsigned getKeyOffset(void * page, unsigned slotNum);
	RC splitPage(void * page, const void *key, const Attribute &attribute, IXFileHandle &handle, void * copyKey, indexDirectoryHeader header, unsigned pageNum, const RID &rid);
	unsigned copyOverKey(const void * fromPage, void * toPage,  unsigned fromOffset, unsigned toOffset,const Attribute &attribute);
	RC splitPageNonLeaf(void * page, const void *key, const Attribute &attribute, IXFileHandle &handle, void * copyKey, indexDirectoryHeader header, unsigned pageNum);
	RC splitPageLeaf(void * page, const void *key, const Attribute &attribute, IXFileHandle &handle, void * copyKey, indexDirectoryHeader header, unsigned pageNum, const RID &rid);
	void printByAttribute(const void *data, const Attribute &attribute) const;
	void recursePrint(IXFileHandle &ixfileHandle, const Attribute &attribute, unsigned currPage) const;
};



class IX_ScanIterator {
    public:

		// Constructor
        IX_ScanIterator();

        // Destructor
        ~IX_ScanIterator();

        // Get next matching entry
        RC getNextEntry(RID &rid, void *key);

        // Terminate index scan
        RC close();
};



class IXFileHandle {
    public:

    FileHandle fh;
    // variables to keep counter for each operation
    unsigned ixReadPageCounter;
    unsigned ixWritePageCounter;
    unsigned ixAppendPageCounter;

    // Constructor
    IXFileHandle();

    // Destructor
    ~IXFileHandle();

	// Put the current counter values of associated PF FileHandles into variables
	RC collectCounterValues(unsigned &readPageCount, unsigned &writePageCount, unsigned &appendPageCount);
        void copyCounterValues();
    private:
/*
        IndexManager *im;
        uint32_t currPage;
        uint32_t currSlot;
        const void* lowVal;
        const void* highVal;
        const void* currVal;
        void *pageData;
        const Attribute attr; 
        CompOp lowCompOp;
        CompOp highCompOp;
        CompOp currCompOp;
        IXFileHandle *ixFH;
        unsigned scanStartPage;
        unsigned scanStartSlot;
        
        RC scanInit(IXFileHandle &ix,
        		const Attribute a,
        		const void *lk,
        		const void *hk,
        		bool lki, 
        		bool hki);
        
        unsigned search(const void *key, bool lowKeyInclusive, IXFileHandle &ixfileHandle, unsigned pageNum);
        bool compare();
        bool compare(int recordInt, CompOp compOp, const void *value);
        bool compare(float recordReal, CompOp compOp, const void *value);
        bool compare(char *recordString, CompOp compOp, const void *value);
*/


};

#endif
